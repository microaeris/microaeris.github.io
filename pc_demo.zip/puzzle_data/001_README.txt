Welcome to the demo! 
Each directory represents a themed set of puzzles. The puzzles require you to form the password on the stack. The password is displayed in the puzzle UI. 

There are three core concepts to the puzzles: the board, the stack, and instructions. The board is the white grid in the puzzle UI. The computer will execute the instructions on the board. The stack is show on the right, it represents the volatile memory of the computer. Instructions are written on the board and executed when you press run. 

When a puzzle is loaded, the board will be pre-populated with letters and instructions. These preloaded letters and instructions cannot be changed. As the player, you are only allowed to input instructions. You cannot add more letters or numbers to the board. Your goal is to form the password on the stack. 

##### Valid Instructions ######

* `[A-Z]`:   Add character to stack
* `>`:       Start moving right
* `<`:       Start moving left
* `^`:       Start moving up
* `v`:       Start moving down
* `@`:       End program
* `(space)`: No-op. Does nothing
* `_`:       Pop a value; move right if value=0, otherwise continue last movement.
* `|`:       Pop a value; move down if value=0, otherwise continue last movement.
* `$`:       Pop value from the stack and discard it
* `:`:       Duplicate value on top of the stack
* `\`:       Swap two values on top of the stack
* `#`:       Bridge: Skip next cell
* `0-9`:     Push this number on the stack
* `+`:       Addition: Pop a and b, then push a+b
* `-`:       Subtraction: Pop a and b, then push b-a
* `*`:       Multiplication: Pop a and b, then push a*b
* `/`:       Integer division: Pop a and b, then push b/a, rounded towards 0.
* `%`:       Modulo: Pop a and b, then push the remainder of the integer division of b/a.
* `!`:       Logical NOT: Pop a value. If the value is zero, push 1; otherwise, push zero.
* `)`:       Shift row right and wrap last character to first column.
* `(`:       Shift row left and wrap first character to last column.
* `.`:       Shift column up and wrap top character to bottom row.
* `,`:       Shift column down and wrap bottom character to top row.
* `&`:       Reverse movement direction of program counter.
* `=`:       Convert element on the top of the stack from char to int or vise versa. 

## Stack

The stack represents the computer's memory. Characters and numbers are added to the stack.

Example:

```
0x00: P
0x01: R
0x02: O
0x03: J
0x04: E
0x05: C
0x06: T
0x07: 0x1
0x08: 0x2
0x09:
0x0A:
0x0B:
0x0C:
0x0D:
0x0E:
0x0F:
```

## Char to Int Conversion

* "A"<->"1"
* "B"<->"2"
* "C"<->"3"
* "D"<->"4"
* "E"<->"5"
* "F"<->"6"
* "G"<->"7"
* "H"<->"8"
* "I"<->"9"
* "J"<->"10"
* "K"<->"11"
* "L"<->"12"
* "M"<->"13"
* "N"<->"14"
* "O"<->"15"
* "P"<->"16"
* "Q"<->"17"
* "R"<->"18"
* "S"<->"19"
* "T"<->"20"
* "U"<->"21"
* "V"<->"22"
* "W"<->"23"
* "X"<->"24"
* "Y"<->"25"
* "Z"<->"26"
